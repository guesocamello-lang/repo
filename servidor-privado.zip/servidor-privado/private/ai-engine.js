// ════════════════════════════════════════════════════════
//  FB Marketplace Item Publisher — ai.js  v4.1
//  Sin ES modules — compatible con Chrome Extension popup
//
//  PARA AGREGAR NUEVAS FUNCIONES DE IA:
//    1. Añade un método al objeto window.ai al final
//    2. Usa window.ai._ask() o window.ai._json() internamente
//    3. Llámalo desde popup.js con: callAI(() => window.ai.tuFuncion())
// ════════════════════════════════════════════════════════

(function () {
  const AI_MODEL   = 'claude-haiku-4-5-20251001';
  const AI_TOKENS  = 1024;
  const AI_API_URL = 'https://api.anthropic.com/v1/messages';

  // ── Core: llamada base ───────────────────────────────
  async function _call(apiKey, messages, systemPrompt = '') {
    const res = await fetch(AI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: AI_MODEL,
        max_tokens: AI_TOKENS,
        system: systemPrompt,
        messages,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || `HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.content?.map(b => b.text || '').join('') || '';
  }

  // ── API pública ──────────────────────────────────────
  window.ai = {

    /** Llama a la IA con texto libre, devuelve string */
    async _ask(apiKey, prompt, system = '') {
      return _call(apiKey, [{ role: 'user', content: prompt }], system);
    },

    /** Llama a la IA esperando JSON, devuelve objeto */
    async _json(apiKey, prompt, system = '') {
      const sys = (system + '\nResponde SOLO con JSON válido, sin explicaciones ni backticks.').trim();
      const raw = await _call(apiKey, [{ role: 'user', content: prompt }], sys);
      try {
        return JSON.parse(raw.replace(/```json|```/g, '').trim());
      } catch {
        throw new Error('La IA no devolvió JSON válido: ' + raw.slice(0, 120));
      }
    },

    // ── Funciones específicas ──────────────────────────

    async generateTitleVariants(apiKey, title, category = '') {
      const catHint = category ? ` en la categoría "${category}"` : '';
      const r = await this._json(apiKey,
        `Genera exactamente 5 variaciones del título "${title}"${catHint} para Facebook Marketplace.
Reglas: máx 99 caracteres, incluye palabras clave naturales, varía estructura y emojis.
No uses el mismo inicio en dos títulos.
Devuelve: { "variants": ["v1","v2","v3","v4","v5"] }`,
        'Eres experto en copywriting para Facebook Marketplace. Solo JSON.'
      );
      return r.variants || [];
    },

    async improveDescription(apiKey, item) {
      return this._ask(apiKey,
        `Mejora esta descripción para Facebook Marketplace:
Ítem: ${item.title}
Precio: $${item.price}
Condición: ${item.condition}
Categoría: ${item.category}
Descripción actual: ${item.desc || '(sin descripción)'}

Escribe 3-5 oraciones vendedoras y amigables. Solo devuelve la descripción.`,
        'Eres experto en ventas online. Responde en el idioma del título.'
      );
    },

    async suggestPrice(apiKey, item) {
      return this._json(apiKey,
        `Sugiere precio para este ítem en Facebook Marketplace (mercado USA):
Título: ${item.title}
Condición: ${item.condition}
Categoría: ${item.category}
Precio actual: $${item.price || 'no definido'}

Devuelve: { "suggested": NUMBER, "min": NUMBER, "max": NUMBER, "reason": "STRING en español (1 oración)" }`,
        'Eres experto en precios de mercado secundario USA. Solo JSON.'
      );
    },

    async analyzePublishError(apiKey, errorLog, item) {
      return this._ask(apiKey,
        `La automatización de Facebook Marketplace falló. Analiza y da 2-3 sugerencias concretas:

Log de errores:
${errorLog}

Ítem que se intentó publicar:
- Título: ${item?.title || 'N/A'}
- Categoría: ${item?.category || 'N/A'}
- Precio: $${item?.price || 'N/A'}

Sé conciso y práctico. Responde en español.`,
        'Eres experto en automatización de Chrome Extensions y Facebook Marketplace.'
      );
    },

    async generateItemFromText(apiKey, shortDesc) {
      return this._json(apiKey,
        `A partir de esta descripción corta, genera un ítem completo para Facebook Marketplace:
"${shortDesc}"

Devuelve exactamente este JSON:
{
  "title": "STRING (max 99 chars, atractivo)",
  "price": NUMBER,
  "category": "una de: Electronics|Clothing & Accessories|Furniture|Home Goods|Toys & Games|Sports & Outdoors|Tools & Home Improvement|Books, Movies & Music|Baby & Kids|Health & Beauty|Pet Supplies|Musical Instruments|Office Supplies|Garden & Outdoor|Auto Parts|Collectibles|Antiques|Other",
  "condition": "una de: New|Like New|Good|Fair|Poor",
  "desc": "STRING descripción 3 oraciones",
  "tags": "STRING 3 tags separados por coma"
}`,
        'Eres experto en Facebook Marketplace. Solo JSON, en el idioma del input.'
      );
    },
  };
})();
