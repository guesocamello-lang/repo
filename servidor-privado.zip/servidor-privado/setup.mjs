import {writeFileSync,existsSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
const domain=process.argv[2];
if(!domain || !/^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/i.test(domain)) throw new Error('Uso: node setup.mjs motor.tudominio.com (sin https ni rutas)');
if(existsSync('.env')) throw new Error('Ya existe .env. Se conserva para no cambiar tus credenciales.');
const token=randomBytes(32).toString('hex');
writeFileSync('.env',`DOMAIN=${domain}\nPUBLIC_URL=https://${domain}\nADMIN_TOKEN=${token}\nDAILY_LIMIT=1000\n# Clave opcional del propietario para IA; también admite la clave del usuario.\nANTHROPIC_API_KEY=\n`,{mode:0o600,flag:'wx'});
console.log(`Configuración creada. Panel: https://${domain}\nTu clave de administrador (guárdala en un gestor de contraseñas):\n${token}`);
