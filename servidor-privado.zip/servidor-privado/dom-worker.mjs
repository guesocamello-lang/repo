import {workerData,receiveMessageOnPort} from 'node:worker_threads';
import {readFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import vm from 'node:vm';
const {port,signal,method,args}=workerData;
const state=new Int32Array(signal);
let serial=0,blockedTime=0,epoch=0;
const refs=new Map(),meta=new WeakMap();
function encode(v){
  if(v===undefined)return {$undefined:true};
  if(v===null||typeof v==='string'||typeof v==='boolean'||typeof v==='number')return v;
  if(meta.has(v))return {$ref:meta.get(v).id};
  if(Array.isArray(v))return v.map(encode);
  if(typeof v==='object')return {$object:Object.fromEntries(Object.entries(v).map(([k,x])=>[k,encode(x)]))};
  throw new Error('Argumento DOM no serializable.');
}
function exchange(action){
  const id=++serial,start=Date.now();
  if(id>100000)throw new Error('Límite de operaciones del trabajo.');
  port.postMessage({type:'command',id,action});
  while(true){
    const message=receiveMessageOnPort(port)?.message;
    if(message){
      if(message.id!==id)throw new Error('Respuesta DOM fuera de secuencia.');
      blockedTime+=Date.now()-start;
      if(message.error)throw new Error(message.error);
      return decode(message.value);
    }
    if(Date.now()-start>90000)throw new Error('El navegador dejó de responder.');
    const tick=Atomics.load(state,0);Atomics.wait(state,0,tick,50);
  }
}
function current(m){return m.snapshot && m.epoch===epoch && Date.now()-m.at<150;}
function decode(v){
  if(v===null||typeof v!=='object')return v;
  if(Array.isArray(v))return v.map(decode);
  if(v.$undefined)return undefined;
  if(v.$object)return Object.fromEntries(Object.entries(v.$object).map(([k,x])=>[k,decode(x)]));
  if(!v.$ref)throw new Error('Respuesta DOM inválida.');
  if(refs.has(v.$ref)){
    const p=refs.get(v.$ref),m=meta.get(p);
    if(v.snapshot){m.snapshot=v.snapshot;m.epoch=epoch;m.at=Date.now();}
    return p;
  }
  const m={id:v.$ref,kind:v.kind,name:v.methodName,snapshot:v.snapshot,epoch,at:Date.now()};
  const target=v.kind==='function'?function(){}:{};
  const proxy=new Proxy(target,{
    get(_t,key){
      if(key==='then')return undefined;
      if(key===Symbol.toStringTag)return 'RemoteDOM';
      if(key===Symbol.toPrimitive)return ()=>`[RemoteDOM ${m.id}]`;
      if(typeof key==='symbol')return undefined;
      if(m.kind==='function' && key==='call')return (receiver,...values)=>{epoch++;return exchange({op:'call',ref:m.id,receiver:encode(receiver),args:values.map(encode)});};
      if(current(m)){
        if(Object.hasOwn(m.snapshot.props,key))return m.snapshot.props[key];
        if(key==='getAttribute')return name=>Object.hasOwn(m.snapshot.attrs,name)?m.snapshot.attrs[name]:exchange({op:'attribute',ref:m.id,name});
        if(key==='getBoundingClientRect')return ()=>m.snapshot.rect;
      }
      if(m.id==='window'&&key==='getComputedStyle')return element=>{
        const em=meta.get(element);
        if(em && current(em))return em.snapshot.style;
        return exchange({op:'style',ref:em?.id});
      };
      return exchange({op:'get',ref:m.id,key});
    },
    set(_t,key,value){epoch++;exchange({op:'set',ref:m.id,key,value:encode(value)});return true;},
    getOwnPropertyDescriptor(_t,key){
      const descriptor=exchange({op:'descriptor',ref:m.id,key});
      return descriptor?{...descriptor,configurable:true}:undefined;
    },
    apply(_t,receiver,values){
      if(!['querySelector','querySelectorAll','getElementById','elementFromPoint','getAttribute','closest','matches','contains','getBoundingClientRect','getComputedStyle'].includes(m.name))epoch++;
      return exchange({op:'call',ref:m.id,receiver:encode(receiver),args:values.map(encode)});
    },
    construct(_t,values){epoch++;return exchange({op:'construct',ref:m.id,args:values.map(encode)});}
  });
  meta.set(proxy,m);refs.set(m.id,proxy);return proxy;
}
class MotorDate extends Date{static now(){return Date.now()-blockedTime;}}
const window=decode({$ref:'window',kind:'object'}),document=decode({$ref:'document',kind:'object'});
const sandbox={window,document,location:decode({$ref:'location',kind:'object'}),Date:MotorDate,setTimeout,clearTimeout,crypto:{randomUUID},console:{log(){},warn(){},error(){}},
  chrome:{storage:{local:{get:async key=>exchange({op:'storage',key})}}},
  RemoteDOM:{file:(src,name,options)=>exchange({op:'file',src,name,options})}
};
for(const name of ['Event','InputEvent','KeyboardEvent','MouseEvent','DataTransfer'])sandbox[name]=decode({$ref:name,kind:'function'});
const source=readFileSync(new URL('./private/browser-engine.js',import.meta.url),'utf8');
const names={diagnose:'injectDiagnoseMarketplace',publish:'injectPublish',relist:'injectRelist',delete:'injectDeleteListings'};
try{
  if(!Object.hasOwn(names,method))throw new Error('Motor desconocido.');
  const context=vm.createContext(sandbox,{codeGeneration:{strings:false,wasm:false}});
  vm.runInContext(source,context,{timeout:1000});
  const result=await context[names[method]](args);
  port.postMessage({type:'done',result});
}catch(e){port.postMessage({type:'done',error:e.message||'El motor privado falló.'});}
finally{port.close();}
