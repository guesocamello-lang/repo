import {Worker,MessageChannel} from 'node:worker_threads';
import {randomUUID} from 'node:crypto';
import {fail} from './store.mjs';
export class Jobs {
  constructor(){this.jobs=new Map();this.timer=setInterval(()=>this.sweep(),10000);this.timer.unref();}
  start(owner,method,args){
    if(!['publish','diagnose','relist','delete'].includes(method)||!args||typeof args!=='object'||Array.isArray(args))fail(400,'Trabajo inválido.');
    if(method==='delete'&&(!Number.isInteger(args.qty)||args.qty<1||args.qty>10))fail(400,'Cantidad de borrado inválida.');
    if([...this.jobs.values()].filter(j=>!j.done).length>=8)fail(503,'Todos los motores están ocupados.');
    if([...this.jobs.values()].some(j=>j.owner===owner&&!j.done))fail(409,'Ya hay un trabajo activo para esta licencia.');
    const id=randomUUID(),channel=new MessageChannel(),signal=new SharedArrayBuffer(4);
    const j={id,owner,signal,port:channel.port1,pending:null,done:false,result:null,error:null,ack:0,seen:Date.now(),started:Date.now(),waiters:new Set()};
    this.jobs.set(id,j);
    j.worker=new Worker(new URL('./dom-worker.mjs',import.meta.url),{workerData:{port:channel.port2,signal,method,args},transferList:[channel.port2],resourceLimits:{maxOldGenerationSizeMb:128,maxYoungGenerationSizeMb:32}});
    channel.port1.on('message',m=>{
      if(j.done)return;
      if(m.type==='command')j.pending={seq:m.id,action:m.action};
      else if(m.type==='done'){j.done=true;j.result=m.result;j.error=m.error||null;j.finished=Date.now();j.pending=null;}
      this.wake(j);
    });
    j.worker.on('error',()=>this.stop(j,'El proceso del motor falló.'));
    j.worker.on('exit',()=>{if(!j.done)this.stop(j,'El proceso del motor terminó antes de completar.');});
    return {job:id};
  }
  get(owner,id){const j=this.jobs.get(id);if(!j||j.owner!==owner)fail(404,'Trabajo no encontrado.');return j;}
  wake(j){for(const fn of j.waiters)fn();j.waiters.clear();}
  stop(j,error){if(j.done)return;j.done=true;j.pending=null;j.error=error;j.finished=Date.now();j.worker.terminate();j.port.close();this.wake(j);}
  cancel(owner,id){this.stop(this.get(owner,id),'Trabajo detenido.');return {ok:true};}
  cancelOwner(owner){for(const j of this.jobs.values())if(j.owner===owner)this.stop(j,'Acceso revocado.');}
  async step(owner,id,ack){
    const j=this.get(owner,id);j.seen=Date.now();
    if(ack&&!j.done){
      if(!Number.isInteger(ack.seq)||ack.seq<1)fail(400,'Secuencia inválida.');
      if(ack.seq!==j.ack){
        if(ack.seq!==j.pending?.seq)fail(409,'Respuesta fuera de secuencia.');
        j.ack=ack.seq;j.pending=null;
        j.port.postMessage({id:ack.seq,value:ack.value,error:typeof ack.error==='string'?ack.error.slice(0,300):undefined});
        Atomics.add(new Int32Array(j.signal),0,1);Atomics.notify(new Int32Array(j.signal),0);
      }
    }
    if(!j.done&&!j.pending)await new Promise(resolve=>{
      const wake=()=>{clearTimeout(t);j.waiters.delete(wake);resolve();};
      const t=setTimeout(wake,15000);j.waiters.add(wake);
    });
    if(j.done)return {done:true,result:j.result,error:j.error};
    if(j.pending)return {command:j.pending};
    return {waiting:true};
  }
  sweep(){
    for(const [id,j] of this.jobs){
      if(!j.done&&(Date.now()-j.seen>45000||Date.now()-j.started>15*60000))this.stop(j,'Se perdió la conexión o se agotó el tiempo del trabajo.');
      if(j.done&&Date.now()-j.finished>60000){j.port.close();this.jobs.delete(id);}
    }
  }
  close(){clearInterval(this.timer);for(const j of this.jobs.values())this.stop(j,'Servidor detenido.');}
}
