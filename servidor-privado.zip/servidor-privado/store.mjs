import {DatabaseSync} from 'node:sqlite';
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
export const hash=v=>createHash('sha256').update(String(v)).digest('hex');
export function fail(status,message){throw Object.assign(new Error(message),{status});}
export class Store {
  constructor(path){
    if(path!==':memory:') mkdirSync(dirname(path),{recursive:true});
    this.db=new DatabaseSync(path);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS licenses(id TEXT PRIMARY KEY,name TEXT NOT NULL,key_hash TEXT UNIQUE NOT NULL,exp INTEGER NOT NULL,revoked INTEGER NOT NULL DEFAULT 0,max_devices INTEGER NOT NULL,created INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS devices(license_id TEXT NOT NULL REFERENCES licenses(id),device TEXT NOT NULL,PRIMARY KEY(license_id,device));
      CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,license_id TEXT NOT NULL REFERENCES licenses(id),device TEXT NOT NULL,exp INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS usage(license_id TEXT,day TEXT,count INTEGER NOT NULL,PRIMARY KEY(license_id,day));`);
  }
  create({name,minutes,maxDevices=1}){
    if(typeof name!=='string'||!name.trim()||name.length>80||!Number.isSafeInteger(minutes)||minutes<1||minutes>5256000||!Number.isInteger(maxDevices)||maxDevices<1||maxDevices>100) fail(400,'Nombre, duración o límite de instalaciones inválidos.');
    const code='MP_'+randomBytes(32).toString('base64url'),id=randomUUID(),now=Date.now();
    this.db.prepare('INSERT INTO licenses VALUES(?,?,?,?,0,?,?)').run(id,name.trim(),hash(code),now+minutes*60000,maxDevices,now);
    return {id,code,exp:now+minutes*60000};
  }
  list(){return this.db.prepare('SELECT id,name,exp,revoked,max_devices,created,(SELECT COUNT(*) FROM devices d WHERE d.license_id=l.id) AS devices FROM licenses l ORDER BY created DESC').all();}
  active(row){if(!row||row.revoked||row.exp<=Date.now()) fail(403,'Licencia inválida, vencida o revocada.');return row;}
  activate(code,device){
    if(typeof code!=='string'||code.length>200||typeof device!=='string'||!/^[a-zA-Z0-9-]{16,80}$/.test(device)) fail(400,'Datos de activación inválidos.');
    const row=this.active(this.db.prepare('SELECT * FROM licenses WHERE key_hash=?').get(hash(code)));
    const exists=this.db.prepare('SELECT 1 FROM devices WHERE license_id=? AND device=?').get(row.id,device);
    if(!exists){
      const {n}=this.db.prepare('SELECT COUNT(*) n FROM devices WHERE license_id=?').get(row.id);
      if(n>=row.max_devices) fail(403,'Límite de instalaciones alcanzado. Contacta al propietario.');
      this.db.prepare('INSERT INTO devices VALUES(?,?)').run(row.id,device);
    }
    this.db.prepare('DELETE FROM sessions WHERE exp<=?').run(Date.now());
    const token=randomBytes(32).toString('base64url'),tokenExp=Math.min(row.exp,Date.now()+15*60000);
    // Keep a small overlap for simultaneous extension contexts renewing a session.
    const old=this.db.prepare('SELECT token_hash FROM sessions WHERE license_id=? AND device=? ORDER BY exp DESC').all(row.id,device);
    for(const s of old.slice(3)) this.db.prepare('DELETE FROM sessions WHERE token_hash=?').run(s.token_hash);
    this.db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(hash(token),row.id,device,tokenExp);
    return {token,tokenExp,license:this.public(row)};
  }
  authorize(token){
    if(typeof token!=='string'||token.length>200) fail(401,'Sesión no válida.');
    const session=this.db.prepare('SELECT * FROM sessions WHERE token_hash=?').get(hash(token));
    if(!session||session.exp<=Date.now()) fail(401,'Sesión vencida.');
    const row=this.active(this.db.prepare('SELECT * FROM licenses WHERE id=?').get(session.license_id));
    if(!this.db.prepare('SELECT 1 FROM devices WHERE license_id=? AND device=?').get(row.id,session.device)) fail(401,'Instalación desautorizada.');
    return row;
  }
  public(row){return {id:row.id,name:row.name,exp:row.exp};}
  update({id,action,minutes}){
    if(typeof id!=='string'||!this.db.prepare('SELECT id FROM licenses WHERE id=?').get(id)) fail(404,'Licencia no encontrada.');
    if(action==='revoke') this.db.prepare('UPDATE licenses SET revoked=1 WHERE id=?').run(id);
    else if(action==='extend'){
      if(!Number.isSafeInteger(minutes)||minutes<1||minutes>5256000) fail(400,'Duración inválida.');
      this.db.prepare('UPDATE licenses SET exp=MAX(exp,?)+?,revoked=0 WHERE id=?').run(Date.now(),minutes*60000,id);
    } else if(action==='reset-devices'){
      this.db.prepare('DELETE FROM devices WHERE license_id=?').run(id);
      this.db.prepare('DELETE FROM sessions WHERE license_id=?').run(id);
    } else fail(400,'Acción inválida.');
    return {ok:true};
  }
  consume(id,limit){
    const day=new Date().toISOString().slice(0,10);
    const row=this.db.prepare('SELECT count FROM usage WHERE license_id=? AND day=?').get(id,day);
    if((row?.count||0)>=limit) fail(429,'Límite diario de operaciones alcanzado.');
    this.db.prepare('INSERT INTO usage VALUES(?,?,1) ON CONFLICT(license_id,day) DO UPDATE SET count=count+1').run(id,day);
    this.db.prepare('DELETE FROM usage WHERE day<?').run(new Date(Date.now()-90*86400000).toISOString().slice(0,10));
  }
}
