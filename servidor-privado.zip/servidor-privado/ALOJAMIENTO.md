# Meta Post 7.3.0 — servidor privado

Este paquete es exclusivamente tuyo. No lo envíes al cliente, no lo pongas en una carpeta pública de descargas y no publiques su repositorio. El cliente recibe solamente `extension-cliente-v7.3.zip` y una licencia individual.

## Qué se ha separado

- El procesamiento de `motor.js`, el preparador de fotos y la variante adicional de `popup.js` se ejecutan en Chromium dentro del servidor. Se conservaron las operaciones de dibujo originales; sus resultados son aleatorios, como antes.
- Las funciones y las instrucciones de IA originales están en `private/ai-engine.js` y se ejecutan en el servidor. Se admite la clave personal de IA que ya utilizaba el cliente; opcionalmente puedes configurar una clave tuya en el servidor.
- La interfaz, los artículos, las ciudades, los controles de cola y agenda, las estadísticas y la importación/exportación permanecen en la extensión.
- Las rutinas de diagnóstico, búsqueda de campos, selección de categorías/condición/ciudad, publicación, renovación y borrado están exclusivamente en `private/browser-engine.js`, dentro del servidor. El navegador de Facebook sigue siendo el del cliente: no se aloja su sesión en un navegador remoto.
- La extensión contiene un puente DOM genérico. El servidor decide una acción, el navegador la ejecuta y devuelve datos necesarios para decidir la siguiente. No se descarga el motor, no hay un evaluador de JavaScript remoto y no se entrega el flujo completo por adelantado. Cada intercambio requiere una sesión autorizada.
- Las licencias firmadas locales se sustituyen por claves aleatorias individuales, verificadas en tu servidor, con vencimiento, revocación y límite de instalaciones. El administrador sigue pudiendo indicar días, horas y minutos.

**Alcance real:** quitar la pantalla o forzar la variable local de licencia no entrega el motor de publicación ni permite obtener órdenes del servidor con una licencia revocada. Sin servidor, el ZIP conserva edición y visualización de datos, pero no contiene el publicador completo de la versión anterior. Un destinatario con acceso autorizado puede observar órdenes y construir su propio automatizador o intentar reproducirlas: ningún ejecutor en su equipo elimina esa posibilidad. El límite de instalaciones no es un bloqueo de hardware; copiar credenciales y el identificador puede permitir compartir una plaza. La revocación impide nuevas órdenes; una acción ya enviada o ejecutada no puede retirarse ni revertirse.

## 1. Lo que necesitas contratar

- Un servidor VPS Linux Ubuntu 24.04, arquitectura x86-64, con acceso SSH. Como punto inicial para pocos usuarios: 2 núcleos, 4 GB de RAM y 20 GB de disco. Es una estimación de arranque, no una capacidad de concurrencia garantizada.
- Un dominio o subdominio que controles, por ejemplo `motor.tudominio.com`.
- Un registro DNS tipo A que apunte ese subdominio a la IP pública del VPS. Si no tienes IPv6 configurado en el VPS, no añadas un registro AAAA.
- Permitir TCP 80 y 443 para HTTPS y emisión del certificado. Mantén SSH accesible solo desde tus IP cuando sea posible. No publiques el puerto 3000.

Activa la verificación en dos pasos en el alojamiento y el registrador. No necesitas enviar a nadie tu contraseña de Facebook ni claves de administración.

## 2. Subir el ZIP privado

En Windows, usa el cliente SFTP de tu preferencia o `scp` desde PowerShell. Sustituye USUARIO y DIRECCION_IP por los datos de tu proveedor:

```powershell
scp .\servidor-privado-v7.3.zip USUARIO@DIRECCION_IP:~/
ssh USUARIO@DIRECCION_IP
```

Una vez dentro de la consola del VPS:

```bash
sudo apt-get update
sudo apt-get install -y unzip
mkdir -p ~/meta-post
unzip ~/servidor-privado-v7.3.zip -d ~/meta-post
cd ~/meta-post/servidor-privado
```

No subas el ZIP a una carpeta web pública.

## 3. Instalar Docker

En un VPS nuevo con Ubuntu, ejecuta el instalador incluido, que configura el repositorio oficial de Docker:

```bash
sudo bash install-docker-ubuntu.sh
```

Si ya tienes aplicaciones alojadas o una instalación de Docker distinta, revisa primero la [guía oficial para Ubuntu](https://docs.docker.com/engine/install/ubuntu/). El instalador no elimina instalaciones anteriores ni resuelve sus conflictos. No es necesario instalar Node en el VPS: se usa dentro de Docker.

## 4. Crear tu configuración y clave privada de administración

Sustituye `motor.tudominio.com` por tu subdominio real. Ejecuta desde la carpeta `servidor-privado`:

```bash
sudo docker run --rm -v "$PWD:/config" -w /config node:24-bookworm-slim node setup.mjs motor.tudominio.com
```

El comando crea `.env` y muestra una clave de administrador aleatoria. Guárdala en un gestor de contraseñas. **Esta es para ti; no es la clave que se entrega al cliente.** No se incluye ninguna credencial real en estos ZIP. Si `.env` ya existe, el comando se niega a sustituirla.

Opcionalmente edita `.env` con `sudo nano .env`:

- `DAILY_LIMIT=1000`: límite combinado diario de procesamientos, solicitudes de IA e inicios de trabajos de automatización por licencia. Los pasos DOM de un mismo trabajo no consumen unidades adicionales. Los intentos fallidos de procesamiento también consumen cuota. Ajústalo al uso previsto; no es un límite monetario de IA.
- `ANTHROPIC_API_KEY=`: déjalo vacío para usar la clave del cliente. Si añades tu propia clave, las solicitudes que no proporcionen una usarán la tuya y el proveedor podrá facturarte. Configura también límites de gasto en ese proveedor.

El modelo y las funciones de IA se conservan respecto al ZIP recibido. Su disponibilidad depende del proveedor y de la cuenta. No se hicieron llamadas reales de pago durante las pruebas.

## 5. Encender el servicio

```bash
sudo docker compose up -d --build
sudo docker compose ps
sudo docker compose logs --tail=60 api caddy
```

La primera construcción descarga Chromium y sus dependencias; puede tardar varios minutos. Caddy obtiene y renueva el certificado cuando el dominio apunta al VPS y los puertos están accesibles. Más información: [HTTPS automático de Caddy](https://caddyserver.com/docs/automatic-https).

Abre en tu navegador:

- `https://motor.tudominio.com/health`: debe mostrar `ok: true`.
- `https://motor.tudominio.com`: tu panel de administración.

Introduce la clave de administrador generada en el paso 4 y pulsa **Entrar / actualizar**. No continúes distribuyendo la extensión hasta que ambos enlaces funcionen con HTTPS válido.

Si aparece error de certificado, comprueba DNS, registros AAAA incorrectos, puertos 80/443 y los registros de Caddy. Si aparece 502, comprueba el estado y los registros de `api`. El puerto 3000 no necesita abrirse a internet.

## 6. Crear una licencia para probar

En el panel:

1. Escribe un nombre identificador.
2. Introduce días, horas y minutos; para la primera prueba usa 30 minutos.
3. Deja 1 instalación si solo quieres autorizar un perfil de navegador.
4. Pulsa **Generar licencia**.
5. Copia la clave mostrada: se muestra una sola vez y el servidor conserva su hash, no la clave original.

La duración comienza al generar, como en la versión recibida. Genera la clave cuando vayas a entregarla. **Extender** añade tiempo y reactiva una licencia revocada. **Revocar** cancela los trabajos de automatización activos de esa licencia y bloquea las siguientes órdenes, comprobaciones y entregas de resultados. **Restablecer instalaciones** permite activar de nuevo, pero no impide que el usuario anterior conserve y reutilice su clave; para retirar acceso, revoca y emite otra.

## 7. Conectar la extensión

1. Respalda/exporta los datos de la versión anterior antes de actualizar.
2. Descomprime `extension-cliente-v7.3.zip`.
3. En Chrome o Edge abre la página de extensiones, activa modo desarrollador y carga la carpeta `extension-cliente`.
4. Abre **Opciones de extensión**, o **Configurar conexión al servidor** en la pantalla de licencia.
5. Escribe `https://motor.tudominio.com`, pulsa **Guardar y conectar** y acepta el permiso para ese dominio.
6. Vuelve al panel y pega la nueva licencia.
7. Procesa una foto y prueba una publicación en **Vista previa**. Comprueba ciudad, texto, foto y categoría antes de publicar realmente.

Para actualizar conservando el almacenamiento, conserva la carpeta y el identificador de la extensión existente: reemplaza sus archivos después de respaldar y pulsa **Recargar**. Instalar desde otra carpeta/perfil puede crear otro identificador y otro almacenamiento. No desinstales antes de respaldar. Las claves antiguas firmadas localmente no son compatibles: debes crear nuevas en este panel.

La extensión pide permiso solo para el dominio configurado; el manifiesto declara HTTPS opcional para que puedas alojar el servidor en tu propio dominio. Las excepciones HTTP son exclusivamente localhost y 127.0.0.1 para pruebas.

## 8. Prueba de aceptación antes de dar acceso

- Abre la extensión sin licencia: debe pedir activación.
- Activa una licencia de prueba y procesa fotos desde el preparador y desde una publicación en vista previa.
- Comprueba artículos, ciudades, variantes, configuración de esperas, estadísticas, importación/exportación y agenda.
- Revoca la licencia con la extensión abierta: el procesamiento y las siguientes validaciones deben quedar bloqueados. La interfaz se comprueba cada 30 segundos. Una acción local ya ejecutada o inyectada en Facebook no se revierte por revocar la licencia.
- Intenta activar la misma clave en otro perfil: debe alcanzar el límite de instalaciones.
- Prueba una licencia de un minuto, espera el vencimiento y comprueba el bloqueo.
- Las pruebas de relist y borrado modifican anuncios: hazlas únicamente con anuncios de prueba. Se conservó la confirmación BORRAR y el máximo original de 10 por sesión.

Después entrega al cliente solo `extension-cliente-v7.3.zip`, tu dirección HTTPS y su clave individual. No entregues el paquete privado, `.env`, la base de datos ni tu clave de administración.

## 9. Límites y tratamiento de datos

- Se ejecuta un procesamiento de fotos/IA a la vez. Los clientes reintentan temporalmente cuando está ocupado. Para varios usuarios intensivos hará falta una cola y dimensionamiento adicional; no es una plataforma de gran escala.
- La automatización admite un trabajo activo por licencia y hasta 8 en total, con límite de 15 minutos por operación individual. Un trabajo abandonado se cancela si pasan 45 segundos sin intercambios. Una cola larga abre un trabajo por artículo; los límites de publicación de la interfaz se conservan.
- La conexión con el servidor añade latencia a las acciones del navegador. Este protocolo se validó localmente; todavía hay que medir el rendimiento con tu VPS y Facebook real. Elige una región cercana a los usuarios. No se promete la velocidad del motor antiguo ejecutado íntegramente en el equipo.
- Cada imagen admite hasta aproximadamente 18 MB antes de base64 y 40 megapíxeles; un trabajo tiene un límite de 60 segundos. Estos límites se añadieron para proteger el servidor. Una imagen que los supere se rechaza; no se reduce silenciosamente.
- Las fotos y resultados se procesan en memoria y no se guardan intencionalmente en el disco del servicio. No hay registro de cuerpos de solicitudes. El sistema operativo, los volcados o la infraestructura del proveedor pueden tener sus propias políticas; no se promete borrado forense de memoria.
- Para dirigir la automatización, se envían al servidor los datos del artículo y los fragmentos/atributos de la página de Marketplace que consulte el motor. Esto puede incluir textos de tus anuncios y otros datos presentes en esos elementos. Informa al usuario de este tratamiento; no es una operación puramente local. No se registran estos cuerpos de solicitud por defecto.
- El puente permite operaciones DOM limitadas y no ofrece acceso a cookies, almacenamiento arbitrario, eval o carga de scripts. La lectura de almacenamiento está limitada a las fotos temporales de publicación. No requiere compartir la contraseña de Facebook con el propietario.
- Los artículos y fotos resultantes siguen almacenados localmente en el navegador. Las funciones de IA envían sus datos al proveedor como antes, ahora a través de tu servidor. No se transmite la sesión de Facebook.
- El servidor usa su propio reloj para licencias y trabajos. Mantén la sincronización de hora del VPS activada.
- Las sesiones duran como máximo 15 minutos y se renuevan mientras la licencia sea válida. La licencia se consulta de nuevo en cada operación privada; un token vigente no evita la revocación.
- La clave de usuario es un secreto de acceso. El límite de instalaciones reduce el uso compartido casual, pero una extensión modificada puede copiar su identificador y sus credenciales. No se confía en ese identificador como prueba de hardware.
- El servidor no sirve la carpeta `private`, el código ni `.env` por HTTP. La imagen Docker ejecuta el servicio como usuario no root y con recursos limitados. Chromium procesa imágenes dentro del contenedor; su sandbox adicional no está activado por defecto en esta configuración. Actualiza las dependencias y restringe el VPS.
- Si el servidor se apaga, el cliente deja de recibir decisiones de publicación, renovación y borrado, además de perder el procesamiento remoto. No se ha incluido ningún motor local de respaldo. La interfaz y los datos guardados continúan visibles; no se borran al revocar.

## 10. Copias de seguridad y mantenimiento

Las licencias están en un volumen persistente de Docker. Reiniciar o recrear los contenedores no las elimina. **No ejecutes `docker compose down -v`**, porque elimina los volúmenes, incluidas las licencias y los certificados.

Para crear una copia consistente mientras funciona:

```bash
sudo docker compose exec api node backup.mjs
sudo docker compose cp api:/app/data/backup.sqlite ./backup-licencias.sqlite
```

Guarda fuera del VPS esa base de datos, `.env` y tu paquete privado, en almacenamiento restringido. Las copias incluyen sesiones y datos de licencias: protégelas. Verifica la restauración en una instancia de pruebas antes de depender de las copias. No sustituyas la base de datos con el servicio en ejecución.

Para reiniciar:

```bash
sudo docker compose restart
```

Para aplicar cambios del servidor:

```bash
sudo docker compose up -d --build
```

No sobrescribas `.env`. Si se filtra la clave de administrador, sustitúyela por otros 32 bytes aleatorios expresados en hexadecimal y recrea `api`; revisa también las licencias existentes. Actualiza el sistema y las imágenes periódicamente, primero en pruebas.

## Verificación incluida y límites de esta entrega

Consulta `VERIFICACION.md`. Se verificó el servidor local, los tres modos de imágenes, la activación/revocación, el circuito extensión → proceso oculto → servidor → almacenamiento local y el motor remoto sobre formularios simulados en el navegador. Se probó la revocación durante una operación y el intento de continuar forzando la licencia local. No se hizo una publicación real en Facebook ni se desplegó en tu VPS. Docker no estaba disponible en el entorno de revisión: el contenedor y la emisión pública de HTTPS están pendientes de probar en el alojamiento.

Fuentes de instalación: [Docker Ubuntu](https://docs.docker.com/engine/install/ubuntu/), [Compose](https://docs.docker.com/compose/install/linux/), [Playwright y dependencias de Chromium](https://playwright.dev/docs/browsers), [Caddy HTTPS](https://caddyserver.com/docs/automatic-https).
