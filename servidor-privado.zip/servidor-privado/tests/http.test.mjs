import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync,cpSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve,dirname,basename} from 'node:path';
import {randomBytes} from 'node:crypto';
import {once} from 'node:events';
import {chromium} from 'playwright';
test('API real: permisos, imágenes, revocación y archivos privados', {timeout:120000},async()=>{
  const dir=mkdtempSync(join(tmpdir(),'meta-post-test-')),admin=randomBytes(32).toString('hex');
  const port=String(18000+Math.floor(Math.random()*10000));const base='http://127.0.0.1:'+port;
  const child=spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,PORT:port,HOST:'127.0.0.1',PUBLIC_URL:base,ADMIN_TOKEN:admin,DB_PATH:join(dir,'db.sqlite')},stdio:['ignore','pipe','pipe']});
  let logs='';child.stderr.on('data',d=>logs+=d);child.stdout.on('data',d=>logs+=d);
  let browser,extensionContext;
  async function post(path,data,token){const r=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(data)});return {status:r.status,data:await r.json()};}
  try {
    let ready=false;
    for(let i=0;i<100;i++){try{if((await fetch(base+'/health')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,200));}
    assert.ok(ready,logs);
    assert.equal((await post('/admin/list',{})).status,401);
    const created=await post('/admin/create',{name:'Prueba',minutes:30,maxDevices:1},admin);assert.equal(created.status,200);
    const active=await post('/v1/activate',{code:created.data.code,device:'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'});assert.equal(active.status,200);
    const token=active.data.token;
    assert.equal((await post('/v1/status',{},token)).status,200);
    assert.equal((await post('/v1/photo',{photo:'x'})).status,401);
    assert.equal((await post('/v1/photo',{photo:'https://example.com/a.jpg'},token)).status,422);
    assert.equal((await post('/v1/ai',{method:'constructor',args:[]},token)).status,400);
    assert.equal((await fetch(base+'/private/photo-engine.js')).status,404);
    assert.equal((await fetch(base+'/private/browser-engine.js')).status,404);
    assert.equal((await post('/v1/jobs/start',{method:'publish',args:{}})).status,401);
    assert.equal((await fetch(base+'/.env')).status,404);
    browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_EXECUTABLE?{executablePath:process.env.CHROMIUM_EXECUTABLE}:{})});
    const page=await browser.newPage();
    const input=await page.evaluate(()=>{const c=document.createElement('canvas');c.width=200;c.height=160;const g=c.getContext('2d');g.fillStyle='red';g.fillRect(0,0,200,160);return c.toDataURL();});
    for(const variant of ['motor','legacy','asset']){
      const out=await post('/v1/photo',{photo:input,variant,format:'image/webp'},token);assert.equal(out.status,200,JSON.stringify(out.data));assert.match(out.data.photo,/^data:image\/(jpeg|webp);base64,/);
      const size=await page.evaluate(async src=>{const im=new Image();im.src=src;await im.decode();return [im.width,im.height];},out.data.photo);assert.ok(size.every(n=>n>0));
    }
    const adminPage=await browser.newPage();const errors=[];adminPage.on('pageerror',e=>errors.push(e.message));
    await adminPage.goto(base);await adminPage.locator('#token').fill(admin);await adminPage.locator('#connect').click();await adminPage.locator('#licenses tr').waitFor();
    assert.equal(await adminPage.locator('#licenses tr').count(),1);assert.deepEqual(errors,[]);
    const blocked=await fetch(base+'/admin/list',{method:'POST',headers:{Origin:'https://untrusted.example','Content-Type':'application/json',Authorization:'Bearer '+admin},body:'{}'});assert.equal(blocked.status,403);
    const extensionSource=new URL('../../extension-cliente',import.meta.url);
    if(existsSync(extensionSource)) {
      const extensionPath=join(dir,'extension');cpSync(extensionSource,extensionPath,{recursive:true});
      const manifest=JSON.parse(readFileSync(join(extensionPath,'manifest.json'),'utf8'));
      manifest.host_permissions.push('http://127.0.0.1/*');writeFileSync(join(extensionPath,'manifest.json'),JSON.stringify(manifest));
      extensionContext=await chromium.launchPersistentContext(join(dir,'profile'),{headless:true,ignoreDefaultArgs:['--disable-extensions'],args:[`--disable-extensions-except=${extensionPath}`,`--load-extension=${extensionPath}`],...(process.env.CHROMIUM_EXECUTABLE?{executablePath:process.env.CHROMIUM_EXECUTABLE}:{})});
      const worker=extensionContext.serviceWorkers()[0]||await extensionContext.waitForEvent('serviceworker');
      const optionsPage=await extensionContext.newPage();
      await optionsPage.goto(worker.url().replace('background.js','options.html'));
      await optionsPage.locator('#server').fill(base);await optionsPage.locator('#save').click();
      await optionsPage.waitForFunction(()=>document.getElementById('status').textContent.startsWith('Conexión guardada'));
      const license2=await post('/admin/create',{name:'Extensión',minutes:30,maxDevices:1},admin);
      await worker.evaluate(async({base,code})=>{await RemoteService.configure(base);const r=await LicenseSystem.activate(code);if(!r.valid)throw new Error(r.error);},{base,code:license2.data.code});
      assert.equal(await worker.evaluate(async()=>(await LicenseSystem.getStatus()).active),true);
      const extPage=await extensionContext.newPage();const extErrors=[];extPage.on('pageerror',e=>extErrors.push(e.message));
      await extPage.goto(worker.url().replace('background.js','popup.html'));
      await extPage.waitForFunction(()=>typeof licenseActive!=='undefined' && licenseActive);
      assert.deepEqual(extErrors,[]);
      assert.equal(await extPage.locator('#license-gate').evaluate(el=>el.classList.contains('show')),false);
      const transformed=await extPage.evaluate(async photo=>(await RemoteService.request('/v1/photo',{photo,variant:'motor'})).photo,input);
      assert.match(transformed,/^data:image\/(jpeg|webp);base64,/);
      // Exercise the actual background -> offscreen -> server -> IndexedDB flow.
      await extPage.evaluate(()=>PhotoVault.init());
      const offscreen=await extPage.evaluate(photos=>new Promise(resolve=>chrome.runtime.sendMessage({action:'iniciarMutacion',photos,batchId:'integration'},resolve)),[input]);
      assert.equal(offscreen.status,'ok',offscreen.error);
      assert.equal(await extPage.evaluate(async()=>(await PhotoVault.get('integration')).length),1);
      // A synthetic Facebook URL is fulfilled locally; no requests/actions reach Facebook.
      const fixture=readFileSync(new URL('./form.html',import.meta.url),'utf8');
      const sellingFixture=readFileSync(new URL('./selling.html',import.meta.url),'utf8');
      await extensionContext.route('https://www.facebook.com/**',route=>route.fulfill({contentType:'text/html',body:route.request().url().includes('/you/selling')?sellingFixture:fixture}));
      const opened=extensionContext.waitForEvent('page');
      const tab=await worker.evaluate(()=>chrome.tabs.create({url:'about:blank',active:true}));
      const formPage=await opened;
      await formPage.goto('https://www.facebook.com/marketplace/create/item');
      await formPage.locator('#publish').waitFor();
      assert.equal(await formPage.locator('select[aria-label=Category] option').count(),2);
      const diagnostic=await extPage.evaluate(tabId=>RemoteAutomation.run(tabId,'diagnose',{}),tab.id);
      assert.equal(diagnostic[0].result.title,true);
      assert.equal(await formPage.locator('select[aria-label=Category] option').count(),2);
      await worker.evaluate(photo=>chrome.storage.local.set({temp_photos_v7:[photo]}),input);
      const entry={title:'Producto de prueba',price:25,category:'Electronics',condition:'New',desc:'Texto original',photos:[],previewOnly:true,tags:'demo',assignedCity:'Miami'};
      const preview=await extPage.evaluate(({tabId,entry})=>RemoteAutomation.run(tabId,'publish',entry),{tabId:tab.id,entry});
      assert.equal(preview[0].result,'ready-to-publish',logs);
      assert.equal(await formPage.locator('[placeholder="Title"]').inputValue(),entry.title);
      assert.equal(await formPage.locator('[aria-label="Price"]').inputValue(),'25');
      assert.equal(await formPage.locator('[aria-label="Category"]').inputValue(),'electronics');
      assert.equal(await formPage.locator('[aria-label="Condition"]').inputValue(),'new');
      assert.equal(await formPage.locator('input[type=file]').evaluate(el=>el.files.length),1);
      assert.equal(await formPage.locator('#city').inputValue(),'Miami');
      assert.equal(await formPage.evaluate(()=>window.publications),0);
      const publish=await extPage.evaluate(({tabId,entry})=>RemoteAutomation.run(tabId,'publish',{...entry,previewOnly:false}),{tabId:tab.id,entry});
      assert.equal(publish[0].result,'ok');assert.equal(await formPage.evaluate(()=>window.publications),1);
      await formPage.goto('https://www.facebook.com/marketplace/you/selling');
      const relist=await extPage.evaluate(tabId=>RemoteAutomation.run(tabId,'relist',{delay:1,city:''}),tab.id);
      assert.equal(relist[0].result,1);assert.equal(await formPage.evaluate(()=>window.renewed),1);
      const deletion=await extPage.evaluate(tabId=>RemoteAutomation.run(tabId,'delete',{qty:1,delay:1}),tab.id);
      assert.equal(deletion[0].result,1);assert.equal(await formPage.evaluate(()=>window.deleted),1);
      // Revoking an active job stops it before it can publish on the synthetic page.
      await formPage.goto('https://www.facebook.com/marketplace/create/item');
      const pending=extPage.evaluate(({tabId,entry})=>RemoteAutomation.run(tabId,'publish',{...entry,previewOnly:false}),{tabId:tab.id,entry}).then(()=>'',e=>e.message);
      await new Promise(r=>setTimeout(r,300));
      await post('/admin/update',{id:license2.data.id,action:'revoke'},admin);
      assert.match(await pending,/revocad|detenid|Licencia/i);
      assert.equal(await formPage.evaluate(()=>window.publications),0);
      assert.equal(await extPage.evaluate(()=>refreshLicenseGate()),false);
      assert.equal(await extPage.locator('#license-gate').evaluate(el=>el.classList.contains('show')),true);
      // Removing the local gate still cannot get a server job with a revoked license.
      await extPage.evaluate(()=>{LicenseSystem.getStatus=async()=>({active:true});licenseActive=true;setLicenseGate(false);});
      await assert.rejects(extPage.evaluate(tabId=>RemoteAutomation.run(tabId,'diagnose',{}),tab.id),/revocad|Licencia/i);
    }
    await post('/admin/update',{id:created.data.id,action:'revoke'},admin);
    assert.equal((await post('/v1/photo',{photo:input},token)).status,403);
    assert.equal((await post('/v1/status',{},token)).status,403);
  } finally {
    await extensionContext?.close();await browser?.close();if(child.exitCode===null){const ended=once(child,'exit');child.kill();await ended;}
    const target=resolve(dir);
    assert.equal(dirname(target),resolve(tmpdir()));assert.ok(basename(target).startsWith('meta-post-test-'));
    rmSync(target,{recursive:true,force:true});
  }
});
