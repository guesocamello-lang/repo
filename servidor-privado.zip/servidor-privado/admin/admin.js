const $=id=>document.getElementById(id);
async function api(path,data={}){
  const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+$('token').value.trim()},body:JSON.stringify(data),cache:'no-store'});
  const out=await r.json();if(!r.ok)throw new Error(out.error);return out;
}
async function refresh(){
  const {licenses}=await api('/admin/list');$('licenses').replaceChildren();
  for(const l of licenses){
    const tr=document.createElement('tr');
    for(const text of [l.name,new Date(l.exp).toLocaleString(),`${l.devices}/${l.max_devices}`]){const td=document.createElement('td');td.textContent=text;tr.append(td);}
    const td=document.createElement('td');td.append(document.createTextNode(l.revoked?'Revocada':l.exp<=Date.now()?'Vencida':'Activa'));
    for(const [label,action] of [['Revocar','revoke'],['Extender','extend'],['Restablecer instalaciones','reset-devices']]){
      const b=document.createElement('button');b.textContent=label;b.onclick=()=>run(async()=>{
        const data={id:l.id,action};
        if(action==='extend'){const value=prompt('Minutos que quieres añadir:','1440');if(value===null)return;data.minutes=Number(value);}
        else if(!confirm(label+' para '+l.name+'?'))return;
        await api('/admin/update',data);await refresh();
      });td.append(b);
    }tr.append(td);$('licenses').append(tr);
  }
}
async function run(fn){try{$('status').textContent='';await fn();}catch(e){$('status').textContent=e.message;}}
$('connect').onclick=()=>run(refresh);
$('lock').onclick=()=>{$('token').value='';$('result').textContent='';$('licenses').replaceChildren();$('status').textContent='Panel bloqueado.';};
$('create').onclick=()=>run(async()=>{
  const vals=['days','hours','minutes'].map(id=>Number($(id).value));
  if(!vals.every(n=>Number.isInteger(n)&&n>=0))throw new Error('La duración debe contener enteros no negativos.');
  const out=await api('/admin/create',{name:$('name').value,minutes:vals[0]*1440+vals[1]*60+vals[2],maxDevices:Number($('devices').value)});
  $('result').textContent=`Clave: ${out.code}\nVence: ${new Date(out.exp).toLocaleString()}`;await refresh();
});
